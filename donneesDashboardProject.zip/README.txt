1) Ouvrez compass
2) Créez une base de donnée que vous appelerez DashboardProject
3) Créer les trois collections (User,Sensor et Measure)
4) Sélectionner la collection dnas laquelle vous souhaitez importer de la donnée dans le menu latéral gauche
5) Dans la barre de menu supérieur, cliquez sur Collection>Import Data 
6) Selectionez JSON et importez le fichier de données json correspondant à la collection selectionnée à l'étape 4
7) Répetez les etapes 4) à 6) pour les trois collections
8) Votre base de données est prête!